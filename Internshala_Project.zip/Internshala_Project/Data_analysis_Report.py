#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings 
warnings.filterwarnings('ignore')
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


# In[2]:


data=pd.read_csv('HDM.csv')


# In[3]:


data.shape


# In[7]:


data.dtypes


# In[4]:


data.info


# In[3]:


data.head()


# In[4]:


data.size


# In[5]:


data.info()


# In[6]:


data.sum()


# In[7]:


data.isnull().sum()


# In[8]:


# 1. Campaign Performance Report
campaign_performance = data.groupby('Campaign ID').agg(
    Total_Calls=('Call Id', 'count'),
    Unique_Leads=('Lead Id', 'nunique'),
    Calls_Connected=('Call Status', lambda x: (x == 'Answered').sum()),
    Unique_Calls_Connected=('Lead Id', lambda x: ((x == 'Answered').sum() > 0).sum()),
    Leads_Converted=('Call Status', lambda x: (x == 'Interested').sum()),
    Qualified_Leads=('Lead Status', lambda x: ...),  # Define criteria based on advertiser requirements
    Leads_Lost=('Call Status', lambda x: (x == 'Not Interested').sum()),
    Avg_Agent_Call_Duration=('Agent Duration(seconds)', 'mean'),
    Avg_Customer_Call_Duration=('Customer Duration(seconds)', 'mean')
).reset_index()


# In[9]:


# 2. Lead Disposition Report
lead_disposition = data['Call Status'].value_counts().reset_index()
lead_disposition.columns = ['Disposition', 'Count']


# In[10]:


# 3. Agent Performance Report
agent_performance = data.groupby('Agent Name').agg(
    Calls_Made=('Call Id', 'count'),
    Calls_Connected=('Call Status', lambda x: (x == 'Answered').sum()),
    Leads_Converted=('Call Status', lambda x: (x == 'Interested').sum()),
    Avg_Agent_Call_Duration=('Agent Duration(seconds)', 'mean'),
    Avg_Customer_Call_Duration=('Customer Duration(seconds)', 'mean')
).reset_index()


# In[11]:


# Print or save the reports
print("Campaign Performance Report:")
print(campaign_performance)
print("\nLead Disposition Report:")
print(lead_disposition)
print("\nAgent Performance Report:")
print(agent_performance)


# In[12]:


# Convert 'Created At' column to datetime
data['Created At'] = pd.to_datetime(data['Created At'])


# In[13]:


# 1. Call Volume Forecast
call_volume_data = data.groupby(pd.Grouper(key='Created At', freq='D')).size().reset_index(name='Call Volume')
call_volume_train = call_volume_data[:-30]['Call Volume']
call_volume_test = call_volume_data[-30:]['Call Volume']


# In[14]:


# 2. Calculate agents' performance metrics
agent_performance = data.groupby('Agent Name').agg(
    Calls_Per_Hour=('Created At', lambda x: x.count() / ((x.max() - x.min()).total_seconds() / 3600)),
    Success_Rate=('Lead Status', lambda x: (x == 'Interested').mean()),
    Avg_Handling_Time=('Agent Duration(seconds)', 'mean')
)


# In[ ]:


# 3. Resource Allocation Forecast
# Calculate call volume forecast as in Objective 1
# Calculate number of agents required based on forecasted call volume and desired performance levels


# In[ ]:


# 4. Estimate workload per agent
# For example, you can calculate the average number of calls per agent per day
avg_calls_per_agent_per_day = call_volume_data['Call Volume'].mean() / len(data['Agent Name'].unique())


# In[ ]:


# Calculate the number of agents required to handle the forecasted call volume
agents_required = avg_calls_per_agent_per_day


# In[ ]:


# 5. Print the forecast
print("Forecasted Call Volume for the next 30 days:")
print("avg_calls_per_agent_per_day")
print("\nEstimated Workload per Agent per Day:", avg_calls_per_agent_per_day)
print("\nNumber of Agents Required to Handle Forecasted Call Volume:", agents_required)


# In[ ]:


sns.pairplot(data, vars=['Call Status', 'Lead Status'])
plt.show()


# In[ ]:


plt.figure(figsize=(10, 6))
plt.plot(call_volume_data['Created At'], call_volume_data['Call Volume'], label='Actual Call Volume')
plt.plot(pd.date_range(start=call_volume_data['Created At'].iloc[-1], periods=30, freq='D'), forecast_call_volume, color='red', label='Forecasted Call Volume')
plt.title('Call Volume Forecast for the Next 30 Days')
plt.xlabel('Date')
plt.ylabel('Call Volume')
plt.legend()
plt.grid(True)
plt.show()


# In[15]:


data = pd.read_csv('HDM.csv')
data['Created At'] = pd.to_datetime(data['Created At'])
call_volume_data = data.groupby(pd.Grouper(key='Created At', freq='D')).size().reset_index(name='Call Volume')

# Step 2: Split the data into training and testing sets
X = pd.to_numeric(call_volume_data['Created At'].dt.dayofyear).values.reshape(-1, 1)
y = call_volume_data['Call Volume'].values
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 3: Train the linear regression model
model = LinearRegression()
model.fit(X_train, y_train)

# Step 4: Evaluate the model
y_pred = model.predict(X_test)
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f'Mean Absolute Error: {mae}')
print(f'Mean Squared Error: {mse}')
print(f'R-squared: {r2}')

# Step 5: Predict call volume
# You can use the trained model to predict call volume for future dates if needed.


# In[19]:


from sklearn.metrics import precision_score, recall_score

# Assuming y_true and y_pred are your true labels and predicted labels, respectively
y_true = [0, 1, 1, 0, 1]  # Example actual labels
y_pred = [0, 1, 0, 0, 1]  # Example predicted labels

precision = precision_score(y_true, y_pred)
recall = recall_score(y_true, y_pred)

precision_percentage = precision * 100
recall_percentage = recall * 100

print(f'Precision: {precision_percentage:.2f}%')
print(f'Recall: {recall_percentage:.2f}%')


# In[6]:


#Pairplot for numeric variables
sns.pairplot(data, vars=["Call Status", "Lead Status", "Campaign ID", "Agent Duration(seconds)", "Customer Duration(seconds)"])
plt.show()


# In[ ]:





# In[ ]:




